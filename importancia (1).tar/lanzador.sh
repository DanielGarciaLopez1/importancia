python /home/daniel_garcia/importancia/importancia_argentina.py & 
python /home/daniel_garcia/importancia/importancia_canada.py &
python /home/daniel_garcia/importancia/importancia_ireland.py &
python /home/daniel_garcia/importancia/importancia_usa.py &