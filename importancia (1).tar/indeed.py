from requests_html import HTMLSession
session = HTMLSession()
r = session.get('https://es.indeed.com/career/salaries/data%20science?from=whatwhere')